
package $pack

class $classname extends grails.plugins.nimble.core.$baseclassname {

	// Extend $baseclassname with your custom values here

}
