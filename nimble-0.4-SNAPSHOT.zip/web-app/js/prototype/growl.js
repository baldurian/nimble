/*
 * growl-prototype
 *
 * Copyright (c) 2009 Prateek Saxena
 * MIT (licensors/prototype/Saxena-MIT-LICENSE.txt)
 *
 * modified by Chris Doty (2010) - added icon class to make more nimble friendly
 *                               - killed sound
 *                               - killed image option, replace with icon class
 */
var Growl=Class.create({initialize:function(a){this.n=0;this.mediaFolder=a||"../src/media/";this.keeper=new Element("div",{"class":"growl-keeper",id:"growl_keeper"});$(document.body).insert({bottom:this.keeper})},display:function(d){this.n++;var b="growl-alert-"+this.n,a=Object.extend({icon:null,delay:3000,autohide:true},arguments[1]||{});this.keeper.insert({bottom:new Element("div",{"class":"growl-alert",id:b,style:"-moz-border-radius:10px;-webkit-border-radius:10px;"})});var c=this;if(a.icon){$(b).insert({top:'<span class="growl-icon icon '+a.icon+'" style="display:table-cell">&nbsp;</span>'})}$(b).insert({bottom:new Element("span",{"class":"growl-text",style:"display:table-cell;background-color:#000000"}).update(d)}).setOpacity(0).appear({to:0.8}).observe("click",function(f){c.remove(Event.findElement(f,"DIV").id)});$(b).observe("mouseover",function(){this.addClassName("growl-alert-hover")});$(b).observe("mouseout",function(){this.removeClassName("growl-alert-hover")});if(a.autohide){this.remove.delay(a.delay/1000,b)}return $(b)},remove:function(a){if(!$(a).hasClassName("growl-alert-hover")){Effect.Fade(a)}else{Effect.Fade.delay(1,a)}}});